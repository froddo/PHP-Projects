<?php $__env->startSection('content'); ?>
    <h1 class="text-danger">Create Todo</h1>
    <hr>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <span class="panel-title "><h3 class="text-danger">Fill in form to create new todo</h3></span>
                </div>
                    <div class="panel-body">
                        <?php echo Form::open(['action' => 'TodosController@store', 'method' => 'POST']); ?>

                        <?php echo e(Form::bsText('text')); ?>

                        <?php echo e(Form::bsTextArea('body')); ?>

                        <?php echo e(Form::bsTextDue('due')); ?>

                        <?php echo e(Form::bsSubmit('Submit', ['class' => 'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>