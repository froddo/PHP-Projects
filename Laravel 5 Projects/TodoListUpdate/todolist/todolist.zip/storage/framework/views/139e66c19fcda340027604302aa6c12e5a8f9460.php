<?php $__env->startSection('content'); ?>
    <a class="btn btn-default" href="/"><span class="glyphicon glyphicon-backward" aria-hidden="true"></span> Go Back</a>
    <hr>
    <div class="panel panel-danger">
        <div class="panel-heading">
            <div class="panel-title"><h3 class="text-center"><?php echo e($todo->text); ?></h3> </div>
        </div>
        <div class="panel-footer"><h4 class="text-success"><?php echo e($todo->body); ?></h4></div>
        <div class="panel-footer"><h4 class="label label-danger"><?php echo e($todo->due); ?></h4></div>

    </div>
    <div class="progress">
        <div class="progress-bar progress-bar-success active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
            <span class="sr-only">45% Complete</span>
        </div>
        <div class="progress-bar progress-bar-danger active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
            <span class="sr-only">45% Complete</span>
        </div>
    </div>
    <a href="/todo/<?php echo e($todo->id); ?>/edit" class="btn btn-success"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Edit</a>
    <?php echo Form::open(['action' => ['TodosController@destroy', $todo->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])); ?>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>