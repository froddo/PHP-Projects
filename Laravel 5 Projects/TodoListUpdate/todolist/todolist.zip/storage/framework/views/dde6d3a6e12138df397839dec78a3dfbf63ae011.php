<!DOCTYPE html>
<html>
<head>
<title>TodoList</title>
<meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/gijgo@1.9.3/combined/css/gijgo.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>

<footer id="footer" class="text-center">
    <h4 class="text-warning">Copyright &copy; <?php echo e(date('Y')); ?></h4>
</footer>
<script src="<?php echo e(asset('/js/app.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.3/combined/js/gijgo.min.js" type="text/javascript"></script>
<script>
    $('#datepicker').datepicker({
        uiLibrary: 'bootstrap'
    });
</script>
</body>
</html>