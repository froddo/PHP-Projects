<?php $__env->startSection('content'); ?>
    <a href="/todo/<?php echo e($todo->id); ?>" class="btn btn-default"><span class="glyphicon glyphicon-backward" aria-hidden="true"></span> Go Back</a>
    <h1 class="text-danger">Edit Todo</h1>
    <hr>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <span class="panel-title "><h3 class="text-danger">Edit form to update todo</h3></span>
                </div>
                <div class="panel-body">
                <?php echo Form::open(['action' => ['TodosController@update', $todo->id], 'method' => 'POST']); ?>

                <?php echo e(Form::bsText('text', $todo->text)); ?>

                <?php echo e(Form::bsTextArea('body', $todo->body)); ?>

                <?php echo e(Form::bsText('due', $todo->due)); ?>

                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                <?php echo e(Form::bsSubmit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>