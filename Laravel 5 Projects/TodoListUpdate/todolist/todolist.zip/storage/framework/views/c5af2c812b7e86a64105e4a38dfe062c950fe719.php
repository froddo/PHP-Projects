<?php $__env->startSection('content'); ?>
<h1 class="text-danger">Todos</h1>
<hr>
<?php if(count($todos) > 0): ?>
    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel panel-warning">
            <div class="panel-heading">
                <div class="panel-title"><h3 class="text-center"><?php echo e($todo->text); ?></h3></div>
            </div>
            <h3><span class="label label-warning pull-right" style="margin-top: 14px;">Created: <?php echo e($todo->created_at); ?></span></h3>
            <h3 class="panel-footer"><span class="label label-danger"><?php echo e($todo->due); ?></span></h3>

            <div class="panel-footer"><a href="/todo/<?php echo e($todo->id); ?>" class="btn btn-primary">More <span class="glyphicon glyphicon-send" aria-hidden="true"></span></a></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($todos->links()); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>