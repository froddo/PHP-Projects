-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2018 at 02:12 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talkingspace`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'PHP-OOP', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"'),
(2, 'Laravel', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"'),
(3, 'BlockChain', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"'),
(4, 'Development', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"'),
(5, 'Design', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `last_activity` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `category_id`, `user_id`, `title`, `body`, `last_activity`, `create_date`) VALUES
(1, 1, 1, 'Why learn Object-oriented PHP?', '<p>Over 80% of websites are now written in PHP, making it more important than ever for web developers to master this programming language. Although the basics are easy to learn, it is the knowledge of Object-oriented PHP that separates the professionals from the hobbyists.</p><p>When using Object-oriented programming, we organize the code in an efficient way, so it is easier to work with, develop and upgrade. Due to its many benefits, developers who master the craft of Object-oriented PHP are a hot commodity in the job market among companies and enterprises that have a need for advanced online applications.</p>', '2018-04-15 20:50:34', '2018-04-15 18:50:34'),
(2, 2, 1, 'What is the best way to learn Laravel?', '<p>Laravel is the one of the most popular PHP frameworks. It is an open source framework and has become a desired skill in PHP developers. It has a neat syntax and comes with a powerful toolkit. There&rsquo;s no surprise that it is the preferred choice of modern web developers as it is loaded with powerful features like eloquent ORM, ease of authentication, clean routing, a decent queue library and many more.</p><p>With Laravel 5, it is super easy. Start here and finish the guide. Just skim through it once and do some practice of the things that catch your interest.&nbsp;</p>', '2018-04-15 21:42:01', '2018-04-15 19:42:01'),
(3, 3, 1, 'Is blockchain technology the new internet?', '<p>The blockchain is an undeniably ingenious invention &ndash; the brainchild of a person or group of people known by the pseudonym, &nbsp;<a href=\"https://en.wikipedia.org/wiki/Satoshi_Nakamoto\">Satoshi Nakamoto</a>. But since then, it has evolved into something greater, and the&nbsp;main question every single person is asking is: What is Blockchain?</p><p>By allowing digital information to be distributed but not copied, blockchain technology created the backbone of a new type of internet. Originally devised for the<a href=\"http://blockgeeks.com/guides/what-is-cryptocurrency-everything-you-need-to-know-ultimate-guide/\">&nbsp;digital currency</a>,&nbsp;<a href=\"http://blockgeeks.com/guides/how-to-buy-bitcoin/\">Bitcoin</a>,&nbsp; (<a href=\"http://coinsquare.io/register?r=BLOCKGEEKS\">Buy Bitcoin</a>) the tech community is now finding other potential uses for the technology.</p>', '2018-04-15 21:46:09', '2018-04-15 19:46:09'),
(4, 4, 1, 'PHP vs Python: what to chose?', '<p>For years, debates have been going on about which of the languages is more user-friendly and most applicable to various tasks: PHP or Python? Despite the many differences between these tools, which consist in a different syntax, different spheres of application and logic, these languages, nevertheless, have a number of common properties.</p><p>They are convenient, easy to learn and use, have many useful libraries, broad communities, and detailed documentation.</p><p>However, to choose the&nbsp;<em>best</em>&nbsp;of two, it all eventually comes down to the purpose of development. Same as in the creation of PHP and Python, before starting to learn the language and developing your own product, it is important to ask the question &ldquo;what exactly do I want to get in the end?&rdquo; To create simple working sites and web applications, as the experience of developers around the world and statistics reaffirm, PHP would be the best solution. However, Python would be the most optimal and convenient tool for the development of complex flexible products.</p><p>When is comes to choosing PHP or Python for mobile development, take into consideration that Python is not limited to the web development capabilities, which make it more versatile than PHP. All the major mobile platforms (iOS,&nbsp;Android, Windows Mobile) have some kind of Python port or framework that allows developing native and web applications with a help of Python.&nbsp;Thanks to its regulations and logic, PHP is better applicable for web development exactly. Though there are ways to&nbsp;build&nbsp;mobile web applications over the PHP server-side&nbsp;backends, it is much harder as compared to Python. Not to mention that the simplest way &ndash; using the solutions by Zend company, is commercial, though&nbsp;not very pricey.</p>', '2018-04-15 22:29:40', '2018-04-15 20:29:40'),
(5, 5, 1, 'Which is the best option, Bootstrap or Materialize CSS?', '<p>Both&nbsp;<strong>Bootstrap</strong>&nbsp;and&nbsp;<strong>Materialize</strong>&nbsp;are Frontend Frameworks;</p><p>Bootstrap is an HTML, CSS, and JavaScript framework, while Materialize is a CSS framework based on Google&#39;s Material Design.&nbsp;<br /><br />The main difference is that Bootstrap gives you more freedom and control over UX elements; Materialize is more opinionated about how UX elements should behave and look, which is to be expected, since the purpose of Materialize is to help you conform your code to Material Design.</p><p><strong>Why do developers choose Bootstrap or Materialize:</strong></p><ul><li>Bootstrap is known for being responsive, consistent, and flexible. It&rsquo;s widely used and well documented, and fans appreciate its responsiveness.</li><li>Materialize is appreciated by fans of Google&rsquo;s Material Design; it&rsquo;s known for being responsive, easy to use, and well documented.</li></ul>', '2018-04-15 22:37:38', '2018-04-15 20:37:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `about` varchar(500) NOT NULL,
  `last_activity` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `join_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `avatar`, `username`, `password`, `about`, `last_activity`, `join_date`) VALUES
(1, 'Rumen', 'rumen@abv.bg', 'about2.jpg', 'topalovr', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'I am full stack Dev', '0000-00-00 00:00:00', '2018-04-15 08:11:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
